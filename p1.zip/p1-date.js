/*
    CIT 281 Project 1
    Name: Jackson Feist
*/

var daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
console.log(daysOfWeek[new Date().getDay()]);